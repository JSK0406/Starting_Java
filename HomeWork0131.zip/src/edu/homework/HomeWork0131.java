package edu.homework;

import java.util.Scanner;

class Car {
	
	protected int vel, num;
	protected String name, color, add;
	
}

class LentCar extends Car {
	
	private int fare;
	private String comp;
	
	public LentCar(int vel, int num, String name, String color, String add, int fare, String comp) {
		this.vel = vel;
		this.num = num;
		this.name = name;
		this.color = color;
		this.add = add;
		this.fare = fare;
		this.comp = comp;
	}

	public int getVel() {
		return vel;
	}
	public void setVel(int vel) {
		this.vel = vel;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	
	public int getFare() {
		return fare;
	}

	public void setFare(int fare) {
		this.fare = fare;
	}

	public String getComp() {
		return comp;
	}

	public void setComp(String comp) {
		this.comp = comp;
	}
	
}

public class HomeWork0131 {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		System.out.print("자동차종류 입력하시오 : ");
		String name = sc.next();
		System.out.print("자동차색깔 입력하시오 : ");
		String color = sc.next();
		System.out.print("자동차번호 입력하시오 : ");
		int num = sc.nextInt();
		System.out.print("운전자주소 입력하시오 : ");
		sc.nextLine();
		String add = sc.nextLine();
		System.out.print("자동차속도를 입력하시오 : ");
		int vel = sc.nextInt();
		System.out.print("렌트비를 입력하시오 : ");
		int fare = sc.nextInt();
		System.out.print("렌트회사를 입력하시오 : ");
		String comp = sc.next();
		
		LentCar mycar = new LentCar(vel, num, name, color, add, fare, comp);
		
		System.out.println("\n");
		
		System.out.println("자동차종류 : " + mycar.getName());
		System.out.println("자동차색깔 : " + mycar.getColor());
		System.out.println("자동차번호 : " + mycar.getNum());
		System.out.println("운전자주소 : " + mycar.getAdd());
		System.out.printf("현재 자동차의 속도는 시속 %skm/h 입니다.\n", mycar.getVel());
		System.out.println("렌트요금 : " + mycar.getFare());
		System.out.println("렌트회사명 : " + mycar.getComp());
		
		System.out.print("속도를 얼마나 올리시겠습니까 : ");
		mycar.setVel(mycar.getVel() + sc.nextInt());
		System.out.printf("현재 자동차의 속도는 시속 %skm/h 입니다.\n", mycar.getVel());
		System.out.print("속도를 얼마나 내리시겠습니까 : ");
		mycar.setVel(mycar.getVel() - sc.nextInt());
		System.out.printf("현재 자동차의 속도는 시속 %skm/h 입니다.\n", mycar.getVel());

	}
	
}

